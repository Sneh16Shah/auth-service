package utils

import (
	"fmt"
	"os"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

type MyCustomClaims struct {
	UserID uint   `json:"user_id"`
	Email  string `json:"email"`
	jwt.RegisteredClaims
}

const tokenIssuer = "auth-service"

func GetTokenizer(userID uint, email string) (string, string, error) {
	accessClaims := MyCustomClaims{
		UserID: userID,
		Email:  email,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(5 * time.Minute)),
			Issuer:    tokenIssuer,
		},
	}
	token_secret := os.Getenv("TOKEN_SECRET")
	if token_secret == "" {
		return "", "", fmt.Errorf("TOKEN_SECRET not set")
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, accessClaims)
	tokenString, err := token.SignedString([]byte(token_secret))
	if err != nil {
		return "", "", err
	}
	refreshToken_secret := os.Getenv("REFRESH_TOKEN_SECRET")
	if refreshToken_secret == "" {
		return "", "", fmt.Errorf("REFRESH_TOKEN_SECRET not set")
	}
	refreshClaims := MyCustomClaims{
		UserID: userID,
		Email:  email,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(5 * 24 * time.Hour)),
			Issuer:    tokenIssuer,
		},
	}
	refreshToken := jwt.NewWithClaims(jwt.SigningMethodHS256, refreshClaims)
	refreshTokenString, err := refreshToken.SignedString([]byte(refreshToken_secret))
	if err != nil {
		return "", "", err
	}
	return tokenString, refreshTokenString, nil
}

func ValidateToken(tokenString string) error {
	claims := MyCustomClaims{}
	token_secret := os.Getenv("TOKEN_SECRET")
	if token_secret == "" {
		return fmt.Errorf("TOKEN_SECRET not set")
	}
	token, err := jwt.ParseWithClaims(tokenString, &claims, func(token *jwt.Token) (interface{}, error) {
		if token.Method == nil || token.Method.Alg() != jwt.SigningMethodHS256.Alg() {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(token_secret), nil
	},
		jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Alg()}),
		jwt.WithIssuer(tokenIssuer),
	)
	if err != nil || !token.Valid {
		return fmt.Errorf("invalid token: %v", err)
	}
	return nil
}

func ParseRefreshToken(tokenString string) (*MyCustomClaims, error) {
	claims := MyCustomClaims{}
	refreshToken_secret := os.Getenv("REFRESH_TOKEN_SECRET")
	if refreshToken_secret == "" {
		return nil, fmt.Errorf("REFRESH_TOKEN_SECRET not set")
	}
	token, err := jwt.ParseWithClaims(tokenString, &claims, func(token *jwt.Token) (interface{}, error) {
		if token.Method == nil || token.Method.Alg() != jwt.SigningMethodHS256.Alg() {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(refreshToken_secret), nil
	},
		jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Alg()}),
		jwt.WithIssuer(tokenIssuer),
	)
	if err != nil || !token.Valid {
		return nil, fmt.Errorf("invalid token: %v", err)
	}
	return &claims, nil
}
